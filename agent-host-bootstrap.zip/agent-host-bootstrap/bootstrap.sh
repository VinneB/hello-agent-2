#!/usr/bin/env bash
set -Eeuo pipefail

# Agent host bootstrap for Arch Linux.
# Run from the root of this repository with: sudo ./bootstrap.sh

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
CONFIG_FILE="${BOOTSTRAP_CONFIG:-$ROOT_DIR/config/bootstrap.conf}"

log() { printf '\n==> %s\n' "$*"; }
warn() { printf '\nWARNING: %s\n' "$*" >&2; }
die() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run with sudo: sudo $0"
[[ -f /etc/arch-release ]] || die "This installer targets Arch Linux."
[[ -r "$CONFIG_FILE" ]] || die "Missing $CONFIG_FILE. Copy config/bootstrap.conf.example to config/bootstrap.conf and edit it first."

# This is a trusted, local configuration file from the bootstrap repository.
# shellcheck source=/dev/null
source "$CONFIG_FILE"

# Optional arrays may be omitted from a local config.
declare -p SSH_ALLOWED_USERS >/dev/null 2>&1 || SSH_ALLOWED_USERS=()
declare -p LOCAL_OUTBOUND_RULES >/dev/null 2>&1 || LOCAL_OUTBOUND_RULES=()

ADMIN_USER="${ADMIN_USER:-${SUDO_USER:-}}"
AGENT_USER="agent"
SHARE_GROUP="project-share"
SSH_PORT="${SSH_PORT:-22}"
ENABLE_NETWORKMANAGER="${ENABLE_NETWORKMANAGER:-no}"
RESET_UFW="${RESET_UFW:-no}"
DISABLE_SSH_PASSWORD_AUTH="${DISABLE_SSH_PASSWORD_AUTH:-no}"

[[ -n "$ADMIN_USER" && "$ADMIN_USER" != root ]] || die "Could not determine a non-root admin user. Set ADMIN_USER in config/bootstrap.conf or run through sudo."
getent passwd "$ADMIN_USER" >/dev/null || die "Admin user '$ADMIN_USER' does not exist. Create the normal admin account before bootstrapping."
[[ "$ADMIN_USER" != "$AGENT_USER" ]] || die "ADMIN_USER cannot be the agent account."
[[ "$AGENT_USER" =~ ^[a-z_][a-z0-9_-]*[$]?$ ]] || die "Invalid AGENT_USER."
[[ "$SHARE_GROUP" =~ ^[a-z_][a-z0-9_-]*$ ]] || die "Invalid SHARE_GROUP."
[[ "$SSH_PORT" =~ ^[0-9]+$ ]] && ((SSH_PORT >= 1 && SSH_PORT <= 65535)) || die "Invalid SSH_PORT."
[[ "$ENABLE_NETWORKMANAGER" == yes || "$ENABLE_NETWORKMANAGER" == no ]] || die "ENABLE_NETWORKMANAGER must be yes or no."
[[ "$RESET_UFW" == yes || "$RESET_UFW" == no ]] || die "RESET_UFW must be yes or no."
[[ "$DISABLE_SSH_PASSWORD_AUTH" == yes || "$DISABLE_SSH_PASSWORD_AUTH" == no ]] || die "DISABLE_SSH_PASSWORD_AUTH must be yes or no."

ADMIN_HOME="$(getent passwd "$ADMIN_USER" | awk -F: '{print $6}')"
[[ -n "$ADMIN_HOME" && -d "$ADMIN_HOME" ]] || die "Could not locate the admin home directory."

declare -p SSH_ALLOWED_CIDRS >/dev/null 2>&1 || die "Define SSH_ALLOWED_CIDRS as an array in config/bootstrap.conf."
declare -p DNS_SERVERS >/dev/null 2>&1 || die "Define DNS_SERVERS as an array in config/bootstrap.conf."
((${#SSH_ALLOWED_CIDRS[@]} > 0)) || die "SSH_ALLOWED_CIDRS must contain at least one source CIDR."
((${#DNS_SERVERS[@]} > 0)) || die "DNS_SERVERS must contain at least one resolver IP."

if ((${#SSH_ALLOWED_USERS[@]} == 0)); then
    SSH_ALLOWED_USERS=("$ADMIN_USER")
fi

admin_ssh_allowed=no
for user in "${SSH_ALLOWED_USERS[@]}"; do
    [[ "$user" =~ ^[a-z_][a-z0-9_-]*[$]?$ ]] || die "Invalid SSH username: $user"
    [[ "$user" != "$AGENT_USER" ]] || die "The agent account must not be allowed to SSH in."
    getent passwd "$user" >/dev/null || die "SSH_ALLOWED_USERS contains unknown user: $user"
    [[ "$user" == "$ADMIN_USER" ]] && admin_ssh_allowed=yes
done
[[ "$admin_ssh_allowed" == yes ]] || die "SSH_ALLOWED_USERS must include the admin account ($ADMIN_USER)."

for cidr in "${SSH_ALLOWED_CIDRS[@]}"; do
    [[ "$cidr" =~ ^[0-9./]+$ ]] || die "Invalid IPv4 SSH source CIDR: $cidr"
    [[ "$cidr" != "0.0.0.0/0" && "$cidr" != "0/0" ]] ||
        die "Refusing to allow SSH from the entire IPv4 internet (0.0.0.0/0)."
done
for dns in "${DNS_SERVERS[@]}"; do
    [[ "$dns" =~ ^[0-9.]+$ ]] || die "DNS_SERVERS must contain IPv4 addresses: $dns"
done
for rule in "${LOCAL_OUTBOUND_RULES[@]}"; do
    IFS='|' read -r proto destination port extra <<< "$rule"
    [[ -z "${extra:-}" && "$proto" =~ ^(tcp|udp)$ && "$destination" =~ ^[0-9./]+$ && "$port" =~ ^[0-9,-]+$ ]] ||
        die "Invalid LOCAL_OUTBOUND_RULES entry: $rule"
done

log "Target admin account: $ADMIN_USER ($ADMIN_HOME)"
log "Agent account: $AGENT_USER"
log "SSH will be allowed from: ${SSH_ALLOWED_CIDRS[*]}"
log "DNS resolvers: ${DNS_SERVERS[*]}"

# A live update is required before installing packages. The machine's base
# networking must already be configured and working.
log "Installing the repository-managed pacman mirrorlist"
if [[ -f "$ROOT_DIR/files/etc/pacman.d/mirrorlist" ]]; then
    if [[ -e /etc/pacman.d/mirrorlist && ! -e /etc/pacman.d/mirrorlist.agent-host-backup ]]; then
        cp -a /etc/pacman.d/mirrorlist /etc/pacman.d/mirrorlist.agent-host-backup
    fi
    install -D -o root -g root -m 0644 "$ROOT_DIR/files/etc/pacman.d/mirrorlist" /etc/pacman.d/mirrorlist
fi

log "Enabling time synchronization before package downloads"
systemctl enable --now systemd-timesyncd.service

log "Updating Arch and installing required packages"
PACKAGES=(acl base-devel ca-certificates curl git inetutils iproute2 jq opencode openssh sudo tmux ufw vim)
if [[ "$ENABLE_NETWORKMANAGER" == yes ]]; then
    PACKAGES+=(networkmanager)
fi
pacman -Syu --needed "${PACKAGES[@]}"

if [[ "$ENABLE_NETWORKMANAGER" == yes ]]; then
    systemctl enable --now NetworkManager.service
fi

# Ensure no separate firewall manager is enabled alongside UFW.
for unit in iptables.service ip6tables.service nftables.service; do
    if systemctl is-enabled --quiet "$unit" 2>/dev/null || systemctl is-active --quiet "$unit" 2>/dev/null; then
        die "$unit is enabled or active. Resolve the firewall-manager conflict before enabling UFW."
    fi
done

log "Creating the shared group and agent account"
getent group "$SHARE_GROUP" >/dev/null || groupadd "$SHARE_GROUP"

if ! id "$AGENT_USER" >/dev/null 2>&1; then
    useradd --create-home --home-dir "/home/$AGENT_USER" --shell /bin/bash "$AGENT_USER"
fi
usermod --shell /bin/bash "$AGENT_USER"
AGENT_HOME="$(getent passwd "$AGENT_USER" | awk -F: '{print $6}')"
[[ "$AGENT_HOME" == "/home/$AGENT_USER" ]] || die "Expected $AGENT_USER home to be /home/$AGENT_USER; found $AGENT_HOME."

# The agent is a normal unprivileged account and cannot log in over SSH.
passwd --lock "$AGENT_USER" >/dev/null 2>&1 || true
# Ensure a private primary group and exactly one supplementary group. This
# removes wheel/docker/other group memberships from any pre-existing account.
getent group "$AGENT_USER" >/dev/null || groupadd "$AGENT_USER"
usermod --gid "$AGENT_USER" --groups "$SHARE_GROUP" "$AGENT_USER"
usermod -aG "$SHARE_GROUP" "$ADMIN_USER"

log "Creating agent workspace, outbox, and admin publishing directories"
for path in "$AGENT_HOME" "$AGENT_HOME/projects" "$AGENT_HOME/outbox"; do
    [[ ! -L "$path" ]] || die "Refusing to manage symlinked agent path: $path"
done
install -d -o "$AGENT_USER" -g "$AGENT_USER" -m 0700 "$AGENT_HOME"
install -d -o "$AGENT_USER" -g "$SHARE_GROUP" -m 2750 "$AGENT_HOME/projects" "$AGENT_HOME/outbox"
[[ ! -L "$ADMIN_HOME/publish" ]] || die "Refusing to use symlinked publishing directory: $ADMIN_HOME/publish"
install -d -o "$ADMIN_USER" -g "$(id -gn "$ADMIN_USER")" -m 0700 "$ADMIN_HOME/publish"

# Admin can traverse /home/agent but cannot list it. The project tree is
# readable/traversable by project-share but not writable by the admin.
setfacl -m "g:$SHARE_GROUP:--x,m::--x" "$AGENT_HOME"
setfacl -m "g::r-x,m::r-x" "$AGENT_HOME/projects"
setfacl -m "d:u::rwx,d:g::r-x,d:m::r-x,d:o::---" "$AGENT_HOME/projects"
setfacl -m "g::r-x,m::r-x" "$AGENT_HOME/outbox"

# Make existing project trees group-readable, but leave the agent as owner.
while IFS= read -r -d '' path; do
    chgrp "$SHARE_GROUP" "$path"
    if [[ -d "$path" ]]; then
        chmod g+rx,g-w,g+s "$path"
        setfacl -m "d:u::rwx,d:g::r-x,d:m::r-x,d:o::---" "$path"
    else
        chmod g+r,g-w "$path"
    fi
done < <(find "$AGENT_HOME/projects" -mindepth 1 \( -type d -o -type f \) -print0)

log "Installing repository-managed system files"
install -D -o root -g root -m 0644 "$ROOT_DIR/files/etc/agent-host/egress-hosts.conf" /etc/agent-host/egress-hosts.conf
install -D -o root -g root -m 0755 "$ROOT_DIR/files/usr/local/sbin/update-openrouter-ufw" /usr/local/sbin/update-openrouter-ufw
install -D -o root -g root -m 0755 "$ROOT_DIR/files/usr/local/bin/agent-export" /usr/local/bin/agent-export
install -D -o root -g root -m 0755 "$ROOT_DIR/files/usr/local/bin/git-ssh-refresh" /usr/local/bin/git-ssh-refresh
install -D -o root -g root -m 0644 "$ROOT_DIR/files/etc/systemd/system/agent-egress-update.service" /etc/systemd/system/agent-egress-update.service
install -D -o root -g root -m 0644 "$ROOT_DIR/files/etc/systemd/system/agent-egress-update.timer" /etc/systemd/system/agent-egress-update.timer
install -D -o root -g root -m 0755 "$ROOT_DIR/files/admin/bin/publish-repo" /usr/local/bin/publish-repo

# Optional OpenCode configuration files live in this repo. No API keys or
# OpenCode SQLite credential database should ever be stored here.
if [[ -f "$ROOT_DIR/files/etc/opencode/opencode.json" ]]; then
    install -D -o root -g root -m 0644 "$ROOT_DIR/files/etc/opencode/opencode.json" /etc/opencode/opencode.json
fi
if [[ -f "$ROOT_DIR/files/home/agent/.config/opencode/opencode.json" ]]; then
    [[ ! -L "$AGENT_HOME/.config" && ! -L "$AGENT_HOME/.config/opencode" ]] ||
        die "Refusing to install OpenCode config through a symlink under $AGENT_HOME/.config"
    install -d -o "$AGENT_USER" -g "$AGENT_USER" -m 0700 "$AGENT_HOME/.config/opencode"
    install -o "$AGENT_USER" -g "$AGENT_USER" -m 0600 \
        "$ROOT_DIR/files/home/agent/.config/opencode/opencode.json" \
        "$AGENT_HOME/.config/opencode/opencode.json"
fi

log "Installing GitHub SSH client configuration for $ADMIN_USER"
ADMIN_SSH_DIR="$ADMIN_HOME/.ssh"
ADMIN_SSH_CONFIG="$ADMIN_SSH_DIR/config"
[[ ! -L "$ADMIN_SSH_DIR" && ! -L "$ADMIN_SSH_DIR/config.d" && ! -L "$ADMIN_SSH_CONFIG" ]] ||
    die "Refusing to install SSH configuration through a symlink in $ADMIN_SSH_DIR"
install -d -o "$ADMIN_USER" -g "$(id -gn "$ADMIN_USER")" -m 0700 "$ADMIN_SSH_DIR" "$ADMIN_SSH_DIR/config.d"
install -o "$ADMIN_USER" -g "$(id -gn "$ADMIN_USER")" -m 0600 \
    "$ROOT_DIR/files/admin/ssh/github-hello-agent.conf" \
    "$ADMIN_SSH_DIR/config.d/github-hello-agent.conf"

# Put the Include at the very beginning. OpenSSH generally uses the first
# obtained value, so placing it after a broad Host * block can break the alias.
if [[ -e "$ADMIN_SSH_CONFIG" ]]; then
    tmp_ssh_config="$(mktemp "$ADMIN_SSH_DIR/.config.XXXXXX")"
    {
        printf 'Include ~/.ssh/config.d/*.conf\n'
        awk '$0 != "Include ~/.ssh/config.d/*.conf"' "$ADMIN_SSH_CONFIG"
    } > "$tmp_ssh_config"
else
    tmp_ssh_config="$(mktemp "$ADMIN_SSH_DIR/.config.XXXXXX")"
    printf 'Include ~/.ssh/config.d/*.conf\n' > "$tmp_ssh_config"
fi
chown "$ADMIN_USER:$(id -gn "$ADMIN_USER")" "$tmp_ssh_config"
chmod 0600 "$tmp_ssh_config"
mv -f "$tmp_ssh_config" "$ADMIN_SSH_CONFIG"

# Configure Git SSH wrapper for the admin account. It refreshes UFW IP rules
# just before Git opens SSH, and sends updater output to stderr.
sudo -u "$ADMIN_USER" env HOME="$ADMIN_HOME" \
    git config --global core.sshCommand /usr/local/bin/git-ssh-refresh
# The admin must not trust agent-writable working trees via safe.directory.
sudo -u "$ADMIN_USER" env HOME="$ADMIN_HOME" \
    git config --global --unset-all safe.directory 2>/dev/null || true

log "Configuring sshd"
[[ -r /etc/ssh/sshd_config ]] || die "Missing /etc/ssh/sshd_config."
grep -Eq '^[[:space:]]*Include[[:space:]]+/etc/ssh/sshd_config.d/\*\.conf' /etc/ssh/sshd_config ||
    die "The main sshd_config does not include /etc/ssh/sshd_config.d/*.conf; add that Include directive before using this installer."
install -d -o root -g root -m 0755 /etc/ssh/sshd_config.d
SSHD_DROPIN="/etc/ssh/sshd_config.d/60-agent-host.conf"
SSHD_TMP="$(mktemp /etc/ssh/sshd_config.d/.60-agent-host.XXXXXX)"
{
    printf 'Port %s\n' "$SSH_PORT"
    printf 'PermitRootLogin no\n'
    printf 'PubkeyAuthentication yes\n'
    printf 'AllowUsers'
    printf ' %s' "${SSH_ALLOWED_USERS[@]}"
    printf '\n'
    if [[ "$DISABLE_SSH_PASSWORD_AUTH" == yes ]]; then
        printf 'PasswordAuthentication no\n'
        printf 'KbdInteractiveAuthentication no\n'
    fi
} > "$SSHD_TMP"
chmod 0644 "$SSHD_TMP"
chown root:root "$SSHD_TMP"

SSHD_BACKUP=""
if [[ -e "$SSHD_DROPIN" ]]; then
    SSHD_BACKUP="$(mktemp /etc/ssh/sshd_config.d/60-agent-host.backup.XXXXXX)"
    cp -a "$SSHD_DROPIN" "$SSHD_BACKUP"
fi
mv -f "$SSHD_TMP" "$SSHD_DROPIN"
/usr/bin/ssh-keygen -A

# Syntax validation alone is insufficient: sshd uses the first value it
# obtains for most directives. Verify the effective settings before reload.
sshd_restore_and_fail() {
    if [[ -n "$SSHD_BACKUP" ]]; then
        mv -f -- "$SSHD_BACKUP" "$SSHD_DROPIN"
    else
        rm -f -- "$SSHD_DROPIN"
    fi
    die "$1; previous drop-in was restored."
}

/usr/bin/sshd -t || sshd_restore_and_fail "sshd syntax validation failed"
SSHD_EFFECTIVE="$(/usr/bin/sshd -T)" || sshd_restore_and_fail "Could not inspect effective sshd configuration"
effective_sshd_value() {
    awk -v key="$1" '$1 == key { $1 = ""; sub(/^ /, ""); print; exit }' <<< "$SSHD_EFFECTIVE"
}
[[ "$(effective_sshd_value port)" == "$SSH_PORT" ]] || sshd_restore_and_fail "Effective sshd port is not $SSH_PORT"
[[ "$(effective_sshd_value permitrootlogin)" == no ]] || sshd_restore_and_fail "Effective PermitRootLogin is not no"
[[ "$(effective_sshd_value pubkeyauthentication)" == yes ]] || sshd_restore_and_fail "Effective PubkeyAuthentication is not yes"
[[ "$(effective_sshd_value allowusers)" == "${SSH_ALLOWED_USERS[*]}" ]] || sshd_restore_and_fail "Effective AllowUsers does not match SSH_ALLOWED_USERS"
if [[ "$DISABLE_SSH_PASSWORD_AUTH" == yes ]]; then
    [[ "$(effective_sshd_value passwordauthentication)" == no ]] || sshd_restore_and_fail "Effective PasswordAuthentication is not no"
    [[ "$(effective_sshd_value kbdinteractiveauthentication)" == no ]] || sshd_restore_and_fail "Effective KbdInteractiveAuthentication is not no"
fi

if [[ -n "$SSHD_BACKUP" ]]; then rm -f -- "$SSHD_BACKUP"; fi
systemctl enable --now sshd.service
systemctl reload sshd.service

log "Preparing UFW rules"
if [[ -f /etc/default/ufw ]]; then
    if [[ ! -e /etc/default/ufw.agent-host-backup ]]; then
        cp -a /etc/default/ufw /etc/default/ufw.agent-host-backup
    fi
    if grep -Eq '^[#[:space:]]*IPV6=' /etc/default/ufw; then
        sed -i -E 's/^[#[:space:]]*IPV6=.*/IPV6=yes/' /etc/default/ufw
    else
        printf '\nIPV6=yes\n' >> /etc/default/ufw
    fi
else
    die "Missing /etc/default/ufw after installing the ufw package."
fi

if [[ "$RESET_UFW" == yes ]]; then
    warn "RESET_UFW=yes will erase all existing UFW rules."
    read -r -p "Type RESET to continue: " confirm_reset
    [[ "$confirm_reset" == RESET ]] || die "UFW reset cancelled."
    ufw --force reset
elif [[ "$RESET_UFW" != no ]]; then
    die "RESET_UFW must be yes or no."
fi

for unit in iptables.service ip6tables.service nftables.service; do
    if systemctl is-enabled --quiet "$unit" 2>/dev/null || systemctl is-active --quiet "$unit" 2>/dev/null; then
        die "$unit is enabled or active. UFW may conflict with it."
    fi
done

ufw default deny incoming
ufw default deny outgoing
ufw default deny routed
ufw logging low

for cidr in "${SSH_ALLOWED_CIDRS[@]}"; do
    ufw allow in from "$cidr" to any port "$SSH_PORT" proto tcp comment 'agent-host-admin-ssh'
done

for dns in "${DNS_SERVERS[@]}"; do
    ufw allow out to "$dns" port 53 proto udp comment 'agent-host-dns'
    ufw allow out to "$dns" port 53 proto tcp comment 'agent-host-dns'
done

# DHCPv4 client requests and NTP client requests. Return traffic is stateful.
ufw allow out 67/udp comment 'agent-host-dhcpv4'
ufw allow out 123/udp comment 'agent-host-ntp'

for rule in "${LOCAL_OUTBOUND_RULES[@]}"; do
    IFS='|' read -r proto destination port _ <<< "$rule"
    ufw allow out to "$destination" port "$port" proto "$proto" comment 'agent-host-local-egress'
done

log "Resolving HTTPS egress destinations and staging their UFW rules"
# Run before enabling the firewall so DNS failures cannot leave a newly
# configured host with an active but unusable outbound-deny policy.
/usr/local/sbin/update-openrouter-ufw

printf '\nThe firewall will now be enabled. SSH sources allowed: %s\n' "${SSH_ALLOWED_CIDRS[*]}"
read -r -p "Type ENABLE to apply the outbound-default-deny firewall: " confirm_fw
[[ "$confirm_fw" == ENABLE ]] || die "Firewall activation cancelled. Rules have been staged but UFW was not enabled."

ufw --force enable
systemctl enable --now ufw.service

log "Enabling the outbound HTTPS allowlist refresh timer"
systemctl daemon-reload
systemctl enable --now agent-egress-update.timer

log "Bootstrap completed"
cat <<SUMMARY

Installed:
  - OpenSSH server
  - UFW with inbound/outbound default deny
  - Git, sudo, tmux, base-devel, vim, ACL utilities
  - OpenCode (Arch package)
  - agent user and project-share group
  - /home/$AGENT_USER/projects (agent writable; project-share read-only)
  - /home/$AGENT_USER/outbox (agent writable; project-share readable)
  - Admin publishing directory: $ADMIN_HOME/publish
  - agent-export and publish-repo commands
  - Git SSH wrapper and github-hello-agent SSH alias
  - Dynamic HTTPS UFW updater and 10-minute systemd timer

Next manual steps:
  1. Log out and back in as $ADMIN_USER so project-share membership takes effect.
  2. Generate the GitHub deploy key as $ADMIN_USER:
       ssh-keygen -t ed25519 -C github-hello-agent -f $ADMIN_HOME/.ssh/github_hello_agent
  3. Add the PUBLIC key to the corresponding GitHub repository Deploy keys.
  4. Verify GitHub's SSH host-key fingerprint before first accepting it:
       ssh -T github-hello-agent
  5. Connect OpenCode to OpenRouter as agent (do not put API keys in this repository).
  6. Review /etc/opencode/opencode.json and the agent user's OpenCode config if you add them to this repo.
  7. Confirm SSH works from an allowed workstation before closing any existing SSH session.

Firewall status:
SUMMARY
ufw status verbose
printf '\nTimer status:\n'
systemctl list-timers agent-egress-update.timer --no-pager
