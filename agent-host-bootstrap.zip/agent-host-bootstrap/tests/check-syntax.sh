#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"

bash -n "$ROOT/bootstrap.sh"
bash -n "$ROOT/config/bootstrap.conf.example"
bash -n "$ROOT/files/usr/local/sbin/update-openrouter-ufw"
bash -n "$ROOT/files/usr/local/bin/agent-export"
bash -n "$ROOT/files/admin/bin/publish-repo"
sh -n "$ROOT/files/usr/local/bin/git-ssh-refresh"
jq empty "$ROOT/files/etc/opencode/opencode.json"

printf 'Static syntax checks passed. This does not replace an Arch VM integration test.\n'
