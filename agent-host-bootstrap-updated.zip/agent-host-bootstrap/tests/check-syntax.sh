#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"

bash -n "$ROOT/bootstrap.sh"
bash -n "$ROOT/config/bootstrap.conf.example"
bash -n "$ROOT/files/usr/local/sbin/update-openrouter-ufw"
bash -n "$ROOT/files/usr/local/bin/agent-export"
bash -n "$ROOT/files/usr/local/bin/agent-sync"
bash -n "$ROOT/files/admin/bin/publish-repo"
bash -n "$ROOT/files/admin/bin/sync-repo"
bash -n "$ROOT/tests/test-sync-workflow.sh"
sh -n "$ROOT/files/usr/local/bin/git-ssh-refresh"
jq empty "$ROOT/files/etc/opencode/opencode.json"

bash "$ROOT/tests/test-sync-workflow.sh"
printf 'Syntax and Git handoff integration tests passed. This does not replace an Arch VM integration test.\n'
