#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
TMP="$(mktemp -d)"
trap 'rm -rf -- "$TMP"' EXIT

export GIT_CONFIG_NOSYSTEM=1
export GIT_CONFIG_GLOBAL="$TMP/gitconfig"
git config --global user.name 'Sync Workflow Test'
git config --global user.email 'sync-test@example.invalid'
git config --global init.defaultBranch main

mkdir -p "$TMP/bin" "$TMP/publish" "$TMP/projects" "$TMP/inbox" "$TMP/seed"
chmod 2750 "$TMP/inbox"

# The production commands enforce the account boundary. Fake only `id -un`
# in this integration test; all other `id` invocations use the system binary.
cat > "$TMP/bin/id" <<'FAKE_ID'
#!/bin/sh
if [ "${1-}" = "-un" ]; then
    printf '%s\n' "${SYNC_TEST_USER:?}"
else
    exec /usr/bin/id "$@"
fi
FAKE_ID
chmod 755 "$TMP/bin/id"
export PATH="$TMP/bin:$PATH"

export AGENT_PUBLISH_ROOT="$TMP/publish"
export AGENT_PROJECTS_ROOT="$TMP/projects"
export AGENT_SYNC_INBOX="$TMP/inbox"
export AGENT_SHARE_GROUP="$(id -gn)"
export AGENT_ACCOUNT_NAME=agent

REMOTE="$TMP/remote.git"
git init --bare "$REMOTE" >/dev/null

git -C "$TMP/seed" init -b main >/dev/null
printf 'initial\n' > "$TMP/seed/README.md"
git -C "$TMP/seed" add README.md
git -C "$TMP/seed" commit -m 'Initial commit' >/dev/null
git -C "$TMP/seed" remote add origin "$REMOTE"
git -C "$TMP/seed" push -u origin main >/dev/null

# Admin publishing clone and agent working clone start from the same history.
git clone "$REMOTE" "$TMP/publish/demo" >/dev/null 2>&1
git clone "$REMOTE" "$TMP/projects/demo" >/dev/null 2>&1
git -C "$TMP/projects/demo" remote remove origin

# Simulate a merge to main on GitHub.
printf 'merged upstream change\n' >> "$TMP/publish/demo/README.md"
git -C "$TMP/publish/demo" add README.md
git -C "$TMP/publish/demo" commit -m 'Merged upstream change' >/dev/null
git -C "$TMP/publish/demo" push origin main >/dev/null

# Add a feature branch on the remote.
git -C "$TMP/publish/demo" switch -c feature/widget >/dev/null 2>&1
printf 'widget\n' > "$TMP/publish/demo/widget.txt"
git -C "$TMP/publish/demo" add widget.txt
git -C "$TMP/publish/demo" commit -m 'Add widget feature' >/dev/null
git -C "$TMP/publish/demo" push -u origin feature/widget >/dev/null
git -C "$TMP/publish/demo" switch main >/dev/null 2>&1

SYNC_REPO="$ROOT/files/admin/bin/sync-repo"
AGENT_SYNC="$ROOT/files/usr/local/bin/agent-sync"

SYNC_TEST_USER=vinne "$SYNC_REPO" demo >/dev/null
[[ -r "$TMP/inbox/demo.bundle" ]]
[[ ! -w "$TMP/inbox/demo.bundle" ]] || {
    # Under root test runs, root can write regardless of mode bits. Check
    # the permission bits instead of access(2).
    mode="$(stat -c '%a' "$TMP/inbox/demo.bundle")"
    [[ "$mode" == 640 ]]
}

SYNC_TEST_USER=agent "$AGENT_SYNC" demo >/dev/null

# Existing checked-out main was fast-forwarded; new feature branch was created.
[[ "$(git -C "$TMP/projects/demo" rev-parse main)" == "$(git -C "$TMP/publish/demo" rev-parse main)" ]]
[[ "$(git -C "$TMP/projects/demo" rev-parse feature/widget)" == "$(git -C "$TMP/publish/demo" rev-parse feature/widget)" ]]

# Verify a non-checked-out local branch can be fast-forwarded safely.
git -C "$TMP/projects/demo" switch feature/widget >/dev/null 2>&1
git -C "$TMP/publish/demo" switch main >/dev/null 2>&1
printf 'second upstream main change\n' >> "$TMP/publish/demo/README.md"
git -C "$TMP/publish/demo" add README.md
git -C "$TMP/publish/demo" commit -m 'Second upstream main change' >/dev/null
git -C "$TMP/publish/demo" push origin main >/dev/null
git -C "$TMP/publish/demo" switch feature/widget >/dev/null 2>&1
SYNC_TEST_USER=vinne "$SYNC_REPO" demo main >/dev/null
SYNC_TEST_USER=agent "$AGENT_SYNC" demo main >/dev/null
[[ "$(git -C "$TMP/projects/demo" rev-parse main)" == "$(git -C "$TMP/publish/demo" rev-parse main)" ]]

# Create divergent commits: one locally in agent, one remotely in admin clone.
git -C "$TMP/projects/demo" switch feature/widget >/dev/null 2>&1
printf 'agent-only\n' > "$TMP/projects/demo/agent-only.txt"
git -C "$TMP/projects/demo" add agent-only.txt
git -C "$TMP/projects/demo" commit -m 'Agent-only work' >/dev/null
LOCAL_FEATURE="$(git -C "$TMP/projects/demo" rev-parse feature/widget)"

printf 'remote-only\n' > "$TMP/publish/demo/remote-only.txt"
git -C "$TMP/publish/demo" switch feature/widget >/dev/null 2>&1
git -C "$TMP/publish/demo" add remote-only.txt
git -C "$TMP/publish/demo" commit -m 'Remote-only work' >/dev/null
git -C "$TMP/publish/demo" push origin feature/widget >/dev/null

SYNC_TEST_USER=vinne "$SYNC_REPO" demo feature/widget >/dev/null
set +e
SYNC_TEST_USER=agent "$AGENT_SYNC" demo feature/widget >/dev/null 2>&1
status=$?
set -e
[[ "$status" -eq 2 ]] || {
    echo "Expected divergence to return exit status 2; got $status" >&2
    exit 1
}
[[ "$(git -C "$TMP/projects/demo" rev-parse feature/widget)" == "$LOCAL_FEATURE" ]] || {
    echo "Diverged local branch was unexpectedly moved." >&2
    exit 1
}
git -C "$TMP/projects/demo" show-ref --verify --quiet refs/sync-inbox/feature/widget

# Dirty worktrees must be rejected without changing the local branch.
printf 'uncommitted\n' >> "$TMP/projects/demo/README.md"
set +e
SYNC_TEST_USER=agent "$AGENT_SYNC" demo >/dev/null 2>&1
status=$?
set -e
[[ "$status" -ne 0 ]] || {
    echo "Expected dirty worktree sync to fail." >&2
    exit 1
}

printf 'Git sync integration tests passed.\n'
