# Agent host bootstrap (Arch Linux)

This repository is a repeatable bootstrap for the dedicated Arch Linux agent host described in the accompanying setup notes. It installs packages, creates the `agent` user and `project-share` group, prepares the read-only admin view of the agent workspace, installs the Git handoff commands, installs OpenCode's managed policy file, configures SSH, and sets up UFW with outbound-default-deny plus a DNS-derived HTTPS allowlist.

**This is a starting point, not a blind one-click installer.** It changes SSH and firewall policy. Review every file and test it from the machine's local console or in a disposable Arch VM before relying on it remotely.

## Assumptions

- A fresh Arch Linux installation is already booted and has working network connectivity.
- A normal administrator account already exists, can use `sudo`, and has a working home directory.
- The administrator account is the only account permitted to SSH into the host by default.
- The initial SSH client source addresses and DNS resolver addresses are known and entered in `config/bootstrap.conf`.
- NetworkManager is optional. The script does not configure Wi-Fi credentials or change the network manager unless explicitly enabled.
- The agent uses remote model APIs; it does not run a local LLM.
- The repository is trusted and should be stored somewhere writable only by the administrator. `bootstrap.sh` sources `config/bootstrap.conf` as shell code and installs the files in this repository as root.

## Repository layout

```text
bootstrap.sh
config/
  bootstrap.conf.example
files/
  etc/
    agent-host/egress-hosts.conf
    opencode/opencode.json
    pacman.d/mirrorlist
    systemd/system/agent-egress-update.{service,timer}
  admin/
    bin/publish-repo
    bin/sync-repo
    ssh/github-hello-agent.conf
  usr/local/
    bin/agent-export
    bin/agent-sync
    bin/git-ssh-refresh
    sbin/update-openrouter-ufw
```

The `files/` tree is the source of truth for installed files. `bootstrap.sh` copies them to their system or user destinations. The sample GitHub SSH alias is for the `hello-agent` repository and its dedicated deploy key. GitHub deploy keys are limited to one repository; for each additional repository, create a separate key and SSH alias, then clone that repo using its alias. GitHub documents this one-key-per-repository model [here](https://docs.github.com/en/authentication/connecting-to-github-with-ssh/managing-deploy-keys). The `publish-repo` command itself is repository-agnostic.

Add your tested user-level OpenCode configuration at:

```text
files/home/agent/.config/opencode/opencode.json
```

That file is optional; the installer copies it if present. The starter repository intentionally does not invent your complete per-user permission/model configuration; copy the known-good one from your existing host, including the GLM `model`/`small_model` selection and your tool permissions. Do not put API keys in it.

## Getting the repository onto a fresh host

The bootstrap cannot download the repository that contains itself. Put this repository on the new machine first, in a directory owned by the administrator and not writable by `agent` (for example, `/home/ADMIN_USER/src/agent-host-bootstrap`). You can transfer it from your workstation with `scp`/USB, or install Git first with a full Arch upgrade (`pacman -Syu --needed git`) and clone it. Do not run the root installer from an `agent`-writable directory.

## Configure before running

Copy the example:

```bash
cp config/bootstrap.conf.example config/bootstrap.conf
vim config/bootstrap.conf
```

At minimum, set:

- `SSH_ALLOWED_CIDRS`: the main workstation's source IP/CIDR as seen by the agent host. Use `/32` for a single IPv4 address where practical.
- `DNS_SERVERS`: the IPv4 resolver address(es) the machine actually uses.

To identify the DNS resolver, inspect `resolvectl status` or `/etc/resolv.conf`. Set `SSH_PORT` to the one SSH server port you intend to use. Inspect the current effective values with `sudo sshd -T | awk '$1 == "port" {print $2}'`. The bootstrap writes `Port $SSH_PORT` to its managed drop-in and refuses configurations with multiple distinct effective ports, because the firewall is configured to allow only one. If the command reports multiple different ports, remove or comment out the unwanted `Port` directives in `/etc/ssh/sshd_config` or `/etc/ssh/sshd_config.d/` before rerunning. To identify the source IP of an established SSH session, inspect `ss -tn state established` and find the connection's local port. Be careful: a DHCP change to the workstation address can make its SSH rule stale.

Optional `LOCAL_OUTBOUND_RULES` entries use this format:

```bash
LOCAL_OUTBOUND_RULES=(
  "tcp|192.168.3.20|22"
  "tcp|192.168.3.30|443"
)
```

Only add local destinations and ports the agent host genuinely needs. The script does not infer them.

Other settings:

- `ADMIN_USER`: normally leave empty; it is detected from `SUDO_USER`.
- `SSH_PORT`: the single SSH listening port the installer configures in its managed `sshd` drop-in and allows through UFW. Remove conflicting `Port` directives elsewhere; the installer rejects multiple distinct effective ports.
- `ENABLE_NETWORKMANAGER=yes`: the example defaults to yes to match the existing host, which uses NetworkManager. Set it to `no` if you use another network manager. The network must already be configured before running the bootstrap. Enabling NetworkManager on a host that currently relies on another network manager may interrupt connectivity; test from a local console.
- `DISABLE_SSH_PASSWORD_AUTH=yes`: set only after the admin's public-key SSH login has been tested from an allowed workstation.
- `RESET_UFW=yes`: erases all existing UFW rules after an interactive `RESET` confirmation. Leave `no` on a normal first run; use only when you intentionally want a clean firewall policy.

## Validate and run

Run the repository's static checks on a development machine with Bash and `jq`:

```bash
tests/check-syntax.sh
```

These checks validate shell syntax and JSON formatting only; they do not exercise package installation, systemd, SSH, ACLs, or live UFW behavior.

## Run

Run from the repository root after creating the local config. If `sudo` is already installed and configured for the admin account:

```bash
sudo ./bootstrap.sh
```

On a minimal Arch installation without `sudo`, use a root console (`su -`) and set `ADMIN_USER` in `config/bootstrap.conf` before running `./bootstrap.sh`. The bootstrap installs `sudo` for subsequent administration, but it assumes the initial administrator account already exists.

The script updates Arch and installs `acl`, `base-devel`, `ca-certificates`, `curl`, `git`, `inetutils`, `iproute2`, `jq`, `opencode`, `openssh`, `sudo`, `tmux`, `ufw`, and `vim`. The admin account must already be able to run the bootstrap as root (or you can run it from a root console with `ADMIN_USER` set in the local config). It enables SSH, validates its configuration, stages UFW rules, and requires you to type `ENABLE` before activating the outbound-default-deny firewall.

The pacman mirrorlist used by this repo is:

- `fastly.mirror.pkgbuild.com`
- `geo.mirror.pkgbuild.com`
- `ohioix.mm.fcix.net`

The original `/etc/pacman.d/mirrorlist` is backed up once as `/etc/pacman.d/mirrorlist.agent-host-backup` before replacement.

## What the installer configures

- `agent` is a locked-password, unprivileged account. Its primary group is `agent` and its only supplementary group is `project-share`; it cannot retain `wheel` or other pre-existing supplementary group privileges. The agent account is explicitly excluded from `AllowUsers`.
- `project-share` contains the admin and agent accounts.
- `/home/agent` remains private except for execute-only traversal by `project-share`.
- `/home/agent/projects` is owned by `agent:project-share`; agent can write, admin can read/traverse but not write. Default ACLs apply the same model to new project content.
- `/home/agent/outbox` is writable by agent and readable by project-share; it carries agent-to-admin bundles.
- `/home/agent/inbox` is admin-owned and writable only by the admin; agent has read-only access for admin-to-agent bundles.
- `$ADMIN_HOME/publish` is private to the admin.
- `agent-export`, `publish-repo`, `sync-repo`, and `agent-sync` provide the Git bundle workflow; all are installed in `/usr/local/bin`.
- The admin SSH config includes the `github-hello-agent` host alias and the `git-ssh-refresh` wrapper.
- `/etc/opencode/opencode.json` contains the managed deny policies captured from the working setup. It does not store provider credentials.
- UFW has IPv6 support enabled and denies incoming, outgoing, and routed traffic by default; it allows inbound SSH only from configured sources, DNS to configured resolvers, DHCPv4 client requests, NTP client requests, configured local-server rules, and dynamically resolved IPv4 addresses for the HTTPS egress hostnames.
- A systemd timer refreshes the HTTPS allowlist every 10 minutes. Git SSH also invokes the updater immediately before connecting.

## Manual steps after installation

1. Log out and back in as the admin user so the new `project-share` supplementary group is active.
2. Generate the GitHub deploy key as the admin user:

   ```bash
   ssh-keygen -t ed25519 -C github-hello-agent -f ~/.ssh/github_hello_agent
   ```

3. Add the `.pub` key to the intended GitHub repository's Deploy keys. Enable write access only if this admin key is supposed to push.
4. Verify GitHub's currently published SSH host-key fingerprint before accepting the first connection. See <https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/githubs-ssh-key-fingerprints>.
5. Test `ssh -T github-hello-agent` and a `git ls-remote` from the admin account.
6. Configure Git commit identity for the agent account (and admin account separately if needed):

   ```bash
   sudo -u agent -H git config --global user.name "Your Commit Name"
   sudo -u agent -H git config --global user.email "YOUR_GITHUB_NOREPLY_EMAIL"
   ```

7. Connect OpenCode to OpenRouter as `agent` interactively. Use a dedicated API key, configure your desired ZDR/retention and spending controls in the provider account, and do not put the key in this repository. OpenCode credentials are stored in its local user data, not in this repository. Never commit `/home/agent/.local/share/opencode/opencode.db`.
8. Copy the known-good agent user config from your existing host into `files/home/agent/.config/opencode/opencode.json`, inspect it for secrets, commit it, and rerun the bootstrap to install it.
9. Confirm SSH access from an allowed workstation in a second session before closing the console/first SSH session.

## Routine Git workflow

The workflow uses two private clones and two one-way bundle handoff directories. Neither account runs Git inside the other account's writable repository, and the agent never receives the GitHub SSH private key.

### Agent to GitHub

As `agent`:

```bash
agent-export REPOSITORY
```

As the admin:

```bash
publish-repo REPOSITORY
```

Review the diff and approve the push when prompted.

### GitHub to agent

After a pull request is merged, or when remote branches otherwise advance, first run as the admin:

```bash
sync-repo REPOSITORY
```

This fetches remote branches into a private ref namespace in the admin publishing clone and writes a bundle to `/home/agent/inbox/REPOSITORY.bundle`. You can limit the bundle to selected branches:

```bash
sync-repo REPOSITORY main feature/some-work
```

Then run as `agent`:

```bash
agent-sync REPOSITORY
```

The agent imports remote tips under `refs/sync-inbox/`. It automatically fast-forwards matching local branches when safe and creates local branches for remote branches that do not yet exist locally. It never force-resets, rebases, deletes local branches, or overwrites a divergent local branch. A dirty working tree blocks the sync. If a local branch has diverged or is checked out in another worktree, the imported ref is retained and the script reports that manual reconciliation is needed.

For a new project, create an empty GitHub repository, clone it as admin into `~/publish/REPOSITORY`, initialize the agent working copy under `/home/agent/projects/REPOSITORY`, commit its initial files, export, and publish. The first push creates the remote branch. Subsequent feature branches publish under their own names by default. After a pull request is merged, use the reverse-sync commands above to update the agent's local branches.

## Important limitations and security notes

- UFW IP allowlisting is not domain-level filtering. A shared CDN IP may host other HTTPS services. The timer reduces stale-DNS windows but cannot make IP rules equivalent to a domain-aware proxy.
- The updater resolves IPv4 only; `git-ssh-refresh` also forces SSH IPv4. IPv6 remains governed by UFW's default policies, but no IPv6 dynamic allowlist is maintained.
- UFW rules are machine-wide, not per-user. Both `agent` and admin can use the same allowed network destinations.
- The OpenCode permission policy is not an OS sandbox. Shell commands still run with the `agent` account's Linux permissions.
- The bundle handoff prevents the admin from running Git in the agent-writable repository. It does not make project source code safe to execute. Review changes before publishing or running project scripts.
- Do not add the agent project tree to Git's `safe.directory` list. The admin should run Git only in the admin-owned publishing clone.
- The bootstrap validates the effective SSH settings with `sshd -T`, not just syntax, before reloading the daemon.
- The initial HTTPS egress updater runs while UFW rules are staged but before the firewall is enabled. If DNS cannot resolve a required hostname, the installer aborts before turning on the outbound-deny firewall.
- The bootstrap has not been executed against your physical Arch installation. Validate it in a disposable Arch VM or local-console test before relying on it on a remote host.
