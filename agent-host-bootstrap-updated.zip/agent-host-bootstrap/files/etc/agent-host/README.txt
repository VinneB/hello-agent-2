The egress-hosts.conf file is consumed by /usr/local/sbin/update-openrouter-ufw.
If you change the pacman mirrors or GitHub SSH endpoint, update this file too.
