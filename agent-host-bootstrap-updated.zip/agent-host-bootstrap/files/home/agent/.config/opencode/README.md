Place the tested, non-secret agent-level OpenCode configuration here as `opencode.json`.
The bootstrap installs that file to `/home/agent/.config/opencode/opencode.json` if it exists.
Keep API/provider credentials in OpenCode's user credential store; do not commit its SQLite database or API keys.
